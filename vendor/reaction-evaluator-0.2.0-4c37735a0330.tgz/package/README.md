# reaction-evaluator

人の話に対する反応(文字起こししたテキスト)を、次の4つに分類します。Node のサーバーで使う前提です。

| `level` | 内容 | 例 |
|---|---|---|
| `"短い相槌"` | 相槌らしく8文字以下、または相槌のセット | 「なるほど」「すごっ」「めんどいよね」「すげえ、マジか天才」 |
| `"長い文章"` | 9文字以上、または開発・プロダクトに関する言葉が入っている | 「それは大変だったね」「いいアイデア」「デザインいいね」 |
| `"迷い"` | 短いが相槌らしくない、相槌らしいか迷う、除外か相槌か迷う | 「その店どこ?」「寒すぎ」「ネット重い」 |
| `"除外"` | 意味のない発声・つなぎの声・やる気のない発言・ゲームシステムの話 | 「あ」「ほげ」「えーっと」「眠い」「ラグい」 |

**この4つの値は、中身を改善しても変えない約束です。** 使う側はこの値でエフェクトなどを出し分けてください。

判定の基準は [data/codebook.md](data/codebook.md) にあります。

## 使う側のプロジェクトでの使い方

### インストール

開発中(こちらで学習し直すと、ビルドするだけで反映される):

```bash
npm install ../jadge/reaction-evaluator
```

この場合は、こちらで `npm run build` してから使ってください(`dist/` を読むため)。

版を固定したいとき(こちらで `npm pack` して作ったファイルを入れる):

```bash
npm install ../jadge/reaction-evaluator/reaction-evaluator-0.2.0.tgz
```

### サーバーでの呼び出し

```ts
import { evaluate, initProximity, initExampleModels } from "reaction-evaluator";

// 起動時に1回だけ(埋め込みモデルと辞書の読み込み。数秒かかる)
await initProximity({ cacheDir: "/var/lib/myapp/models" }); // 埋め込みモデルの保存先(消えない場所)
await initExampleModels(); // 学習結果(models/*.json)の読み込み

// 1件ずつ判定
const result = await evaluate({
  source: "昨日駅前のラーメン屋行ったんだけどさ", // 元の話(空でもよい。関係がある反応を除外しないために使う)
  reaction: "なるほど",
});
result.level; // "短い相槌" | "長い文章" | "迷い" | "除外"
```

React など画面側には `level` だけを返せば十分です。判定はブラウザでは行いません(モデルが重いため)。

API の例:

```ts
// POST /evaluate  { source, reaction } → { level }
app.post("/evaluate", async (req, res) => {
  const { source = "", reaction } = req.body;
  const { level } = await evaluate({ source, reaction });
  res.json({ level });
});
```

### 結果に入っているもの

| 項目 | 内容 |
|---|---|
| `level` | 分類(上の4つ) |
| `rule` | 決め手になったルール(`"短い相槌"` / `"長い文章"` / `"長い文章:プロダクトの話"` / `"短い相槌:相槌のセット"` / `"迷い:短いが相槌らしくない"` / `"迷い:相槌らしさ"` / `"迷い:除外か相槌か"` / `"除外:意味のない発声"` / `"決まり文句"`) |
| `length` | 末尾の記号・w・伸ばし棒を除いた文字数 |
| `scores` | 相槌らしさ・除外・元の話との関係のスコア(0〜1) |

### 注意
- **初回起動で埋め込みモデル(約1.1GB)をダウンロードします。** `cacheDir` は消えない場所にしてください。
- **1件あたり数十〜100ms ほどかかります。** 反応が大量に来るときは、同時に処理する数を絞ってください。
- **Node 23.6 以上**が必要です。

## こちら(改善する側)の作業

| やること | コマンド |
|---|---|
| 学習例を足す | `data/examples.csv` を編集(書き方は [data/codebook.md](data/codebook.md)) |
| 学習し直す | `npm run train` |
| テスト | `npm test` |
| 型チェック | `npm run typecheck` |
| ビルド(使う側がローカルのパスで入れているとき) | `npm run build` |
| 版を固定して渡す | `package.json` の `version` を上げて `npm pack` |

学習データだけを増やした場合は `models/*.json` が変わるだけなので、使う側はパッケージを更新するだけで済みます。

主な設定は `src/config.ts` にあります。

| 設定 | 内容 |
|---|---|
| `SHORT_AIZUCHI_MAX_LENGTH` | 短い相槌の文字数の上限(8) |
| `EXCLUSION_UNSURE_MARGIN` | 除外と相槌らしさのスコアの差がこれ未満なら「迷い」(0.2) |
| `NONSENSE_WORDS` | ルールで除外する意味のない言葉・つなぎの声(「ほげ」「てすと」「えーっと」など) |
| `PRODUCT_WORDS` | 入っていたら長い文章にする開発・プロダクトの言葉(「デザイン」「発想」「アイデア」など) |
| `AGREEMENT_ENDINGS` | 相槌にする同意の語尾(「よね」「ね」) |
| `STOCK_PHRASES` | モデルを使わずに短い相槌にする決まり文句 |
| `THRESHOLDS` / `EXCLUSION_THRESHOLDS` | スコアの境目 |

埋め込みモデルの保存先は、学習やスクリプトでは環境変数 `MODEL_CACHE_DIR` で指定できます。

## フォルダ

| 場所 | 中身 |
|---|---|
| `src/` | 判定のコード |
| `models/` | 学習結果(`npm run train` で作る。パッケージに含まれる) |
| `data/` | 学習例・テスト用データ・コードブック・選別用の候補 |
| `scripts/` | 学習(`train.ts`)、近さの評価の確認(`check-proximity.ts`) |
| `test/` | テスト |
| `dist/` | ビルド結果(`npm run build` で作る) |
